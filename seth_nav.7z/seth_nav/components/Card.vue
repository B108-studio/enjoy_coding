<template>
  <div v-if="video" class="card flex flex-col">
    <div class="flex-grow">
      <div>
        <img
          :src="video.thumbnail.url"
          :alt="video.title"
          class="card_image"
          @click="gotoVideoPage(video)"
        />
      </div>
      <div class="px-3 py-2">
        <a @click="gotoVideoPage(video)">
          <div class="font-bold text-base text-gray-700">{{ video.title }}</div>
        </a>
      </div>
    </div>
    <div class="px-3 py-2 border-t border-gray-200">
      <div class="flex justify-between">
        <div>
          <a :href="playlistUrl" v-if="playlistId" target="_blank">
            <img
              src="/images/youtube.png"
              alt="赛斯资料"
              class="w-5 h-5 opacity-80"
            />
          </a>
          <NuxtLink v-if="storeId" :to="'/playlist/' + storeId">
            <svg
              class="w-5 h-5 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
              ></path>
            </svg>
          </NuxtLink>
        </div>
        <div class="flex items-center text-xs text-green-700">
          {{ video.publishedAt }}
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { mapMutations } from "vuex";
export default {
  name: "Card",
  data: function () {
    return {};
  },
  props: {
    video: {
      type: Object,
      required: true,
    },
    playlistId: String, // 直接连接Youtube播单
    storeId: String, // 连接本地播单 -> /playlist/nuxtjs
  },
  computed: {
    // 映射store.state
    ...mapState({
      siteName: (state) => state.siteName,
      // playlists: (state) => state[list.store_id].list,
    }),
    playlistUrl: function () {
      return this.$makeYoutubePlaylistUrl(this.playlistId);
    },
    videoUrl: function () {
      return this.$makeYoutubeVideoUrl(this.video.videoId);
    },
  },
  methods: {
    // 映射store.mutations
    ...mapMutations({
      setVideoObj: "setVideoObj",
    }),
    gotoVideoPage: function (video) {
      this.setVideoObj(video);
      window.$nuxt.$router.push("/video/" + video.videoId);
    },
  },
};
</script>