<template>
  <div class="bg-gray-50 p-3 border-b border-gray-300 shadow-xs mb-3">
    <div class="flex justify-between">
      <NuxtLink to="/">
        <div class="flex items-center">
          <img src="/favicon.ico" :alt="siteName" class="rounded w-5 h-5" />
          <h3 class="pl-1 text-gray-700">
            {{ siteName }}
          </h3>
        </div>
      </NuxtLink>
      <div class="flex items-center">
        <NuxtLink to="/tag">
          <img src="/images/tag.png" alt="视频标签" class="w-5 h-5" />
        </NuxtLink>
        <a
          href="https://www.youtube.com/channel/UCk9VLAzk6CJiSsyDccAFcFA"
          target="_blank"
        >
          <img
            src="/images/youtube.png"
            alt="DEAR HELEN"
            class="w-5 h-5 ml-3"
          />
        </a>
        <a href="https://space.bilibili.com/632831023/" target="_blank">
          <img
            src="/images/bilibili.png"
            alt="Bilibili"
            class="w-5 h-5 ml-3 opacity-80"
          />
        </a>
        <NuxtLink to="/about">
          <img src="/images/about.png" alt="关于" class="w-5 h-5 ml-3" />
        </NuxtLink>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "shared_header",
  data: function () {
    return {};
  },
  props: {},
  computed: {
    // 映射store.state
    ...mapState({
      siteName: (state) => state.siteName,
    }),
  },
  methods: {},
};
</script>Ï