<template>
  <div class="bg-gray-50 p-3 mt-5 h-20 border-gray-800 text-center">
    <h3>Copyright (C) {{ siteName }} setha.cn All rights reserved.</h3>
    <div>
      <a href="#" class="text-blue-700">Back to top</a>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "shared_footer",
  data: function () {
    return {};
  },
  props: {},
  computed: {
    // 映射store.state
    ...mapState({
      siteName: (state) => state.siteName,
    }),
  },
};
</script>