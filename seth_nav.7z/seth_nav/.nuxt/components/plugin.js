import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Card: () => import('../../components/Card.vue' /* webpackChunkName: "components/card" */).then(c => wrapFunctional(c.default || c)),
  TagLabel: () => import('../../components/TagLabel.vue' /* webpackChunkName: "components/tag-label" */).then(c => wrapFunctional(c.default || c)),
  SharedFooter: () => import('../../components/shared/Footer.vue' /* webpackChunkName: "components/shared-footer" */).then(c => wrapFunctional(c.default || c)),
  SharedHeader: () => import('../../components/shared/Header.vue' /* webpackChunkName: "components/shared-header" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
