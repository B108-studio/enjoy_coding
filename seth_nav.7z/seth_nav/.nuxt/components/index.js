import { wrapFunctional } from './utils'

export { default as Card } from '../../components/Card.vue'
export { default as TagLabel } from '../../components/TagLabel.vue'
export { default as SharedFooter } from '../../components/shared/Footer.vue'
export { default as SharedHeader } from '../../components/shared/Header.vue'

export const LazyCard = import('../../components/Card.vue' /* webpackChunkName: "components/card" */).then(c => wrapFunctional(c.default || c))
export const LazyTagLabel = import('../../components/TagLabel.vue' /* webpackChunkName: "components/tag-label" */).then(c => wrapFunctional(c.default || c))
export const LazySharedFooter = import('../../components/shared/Footer.vue' /* webpackChunkName: "components/shared-footer" */).then(c => wrapFunctional(c.default || c))
export const LazySharedHeader = import('../../components/shared/Header.vue' /* webpackChunkName: "components/shared-header" */).then(c => wrapFunctional(c.default || c))
