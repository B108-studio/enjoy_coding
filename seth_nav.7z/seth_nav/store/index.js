export const state = () => ({
    siteName: "赛斯资料",
    // 进入视频页面前设置这个属性
    videoObj: null,
    playlists: [
        { "store_id": "eternal_validity", "playlistId": "PL1nqXwMyheM63y-_4RbEKkVosf9exu0qR", "title": "《灵魂永生》译者王季庆 赛斯书 Seth Speaks 海轮海轮朗读 有声书" },
        { "store_id": "eternal_validity_2021", "playlistId": "PL1nqXwMyheM4vkG09K6Hyi9oB2k6ThNSC", "title": "（合集）灵魂永生 赛斯书" },
        { "store_id": "mass_events", "playlistId": "PL1nqXwMyheM5t8MXDXAYT1sCLzabGGZMJ", "title": "《个人与群体事件的本质》有声书" },
        { "store_id": "personal_reality", "playlistId": "PL1nqXwMyheM66UzHmtFM5D_F7cxkWyDta", "title": "《个人实相的本质-赛斯书》" },
        { "store_id": "magic_approach", "playlistId": "PL1nqXwMyheM62NVcWcL3doh310N93ypsg", "title": "赛斯书系列之 《神奇之道》The Magical Approach Jane Roberts Seth 珍 罗伯兹" },
        { "store_id": "psyche", "playlistId": "PL1nqXwMyheM4fP60rJ6YiDW0FZ68Y_JRh", "title": "《灵性的本质》 珍 罗伯兹 赛斯 王季庆 Jane Roberts Seth Robert Butts （又名《心灵的本质》）The Nature of the Psyche" },
        { "store_id": "seth_speaks_en", "playlistId": "PL1nqXwMyheM419QGRYFf4sGKjKGv1YO4H", "title": "Seth Speaks  Audiobook by DEAR HELEN 海轮海轮" },
        { "store_id": "seth_speaks", "playlistId": "PL1nqXwMyheM5hQeFEuZRiW8KvdOHdEuff", "title": "合集0 赛斯书《时空之外》 by Dear Helen （海轮海轮）" },
        { "store_id": "unknown_reality", "playlistId": "PL1nqXwMyheM6747mgjxGM_5HyY7z7uJZw", "title": "《未知的实相》卷一 罗伯柏兹 注记 珍罗伯兹 著 赛斯书 王季庆译 " },
        { "store_id": "unknown_reality_xiyu", "playlistId": "PL1nqXwMyheM44kEcpkpiMi3xxXZi3Dp87", "title": "1 赛斯序 细雨导读 《未知的实相》 卷一 珍罗伯兹著 罗伯柏兹注记 王季庆译 细雨解读" },
    ]
})

export const mutations = {
    setVideoObj(state, video) {
        state.videoObj = video
    }
}