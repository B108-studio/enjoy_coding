<template>
    <div class="mainbody">
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-7">
            <Card v-for="video in list" :key="video.videoId" :video="video" :storeId="video.store_id" />
        </div>
    </div>
</template>

<script>
    import { mapState } from 'vuex'

    export default {
        computed: {
            // 映射store.state
            ...mapState({
                list: (state) => state.home.list,
            }),
        },
    };
</script>

<style>
    .mainbody {
        min-height: 480px;
    }
</style>