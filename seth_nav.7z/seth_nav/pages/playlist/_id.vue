<template>
    <div v-if="videolist">
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-7">
            <Card v-for="video in videolist" :key="video.videoId" :video="video" :playlistId="video.playlistId" />
        </div>

    </div>
</template>

<script>
    // https://vuex.vuejs.org/zh/
    // import { mapState } from 'vuex'
    // import { mapGetters } from "vuex";
    // import { mapMutations } from 'vuex'
    // import { mapActions } from 'vuex';
    // @ is an alias to /src
    // import HelloWorld from "@/components/HelloWorld.vue";

    export default {
        name: "playlist",
        components: {
            // HelloWorld
        },
        data: function () {
            return {};
        },
        props: {},
        computed: {
            // 映射store.getters
            // ...mapGetters({
            //     siteName: "getSiteName"
            // }),
            // 映射store.state
            // ...mapState({
            //     siteName: (state) => state.siteName,
            // }),
            playlist_id: function () {
                return this.$route.params.id;
            },
            videolist: function () {
                return this.$store.state[this.playlist_id].list;
            }
        },
        methods: {
            // 映射store.mutations
            // ...mapMutations({
            //     add: 'increment'
            // }),
            // 映射store.actions
            // ...mapActions({
            //     search: 'search'
            // }),
        },
        beforeCreate: function () { },
        created: function () { },
        beforeMount: function () { },
        mounted: function () { },
        beforeUpdate: function () { },
        updated: function () { },
        activated: function () { },
        deactivated: function () { },
        beforeDestroy: function () { },
        destroyed: function () { },
        errorCaptured: function () { }
    };
</script>

<style scoped>
</style>