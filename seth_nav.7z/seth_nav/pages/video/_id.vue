<template>
  <div>
    <div v-if="this.video">
      <div class="flex flex-col items-center">
        <div
          class="text-3xl text-gray-600 sm:w-full md:w-9/12 lg:w-6/12 leading-10 text-left"
        >
          {{ this.video.title }}
        </div>
        <hr class="mt-3 sm:w-full md:w-9/12 lg:w-6/12 border border-gray-300" />
        <div class="mt-3 sm:w-full md:w-9/12 lg:w-6/12 flex justify-between">
          <div class="flex justify-start">
            <div
              class="bg-green-500 rounded-3xl text-white text-xs px-2 py-1 font-bold w-auto shadow"
            >
              赛斯资料
            </div>
            <div
              class="bg-blue-500 rounded-3xl text-white text-xs px-2 py-1 font-bold w-auto ml-1 shadow"
            >
              <NuxtLink :to="'/playlist/' + video.store_id">
                {{ video.store_id }}
              </NuxtLink>
            </div>
          </div>
          <div
            class="bg-red-500 rounded-3xl text-white text-xs px-2 py-1 font-bold w-auto shadow-md"
          >
            {{ this.video.publishedAt }}
          </div>
        </div>
        <div
          class="mt-5 w-full sm:w-full md:w-8/12 lg:w-5/12 border border-gray-300 rounded"
        >
          <a :href="this.$makeYoutubeVideoUrl(video.videoId)" target="_blank">
            <img
              :src="this.video.thumbnail.url"
              :alt="this.video.title"
              class="w-full border-4 border-white shadow rounded"
            />
          </a>
        </div>
        <hr
          class="mt-10 sm:w-full md:w-9/12 lg:w-6/12 border border-gray-300"
        />
        <div class="mt-3 sm:w-full md:w-9/12 lg:w-6/12">
          <div class="flex justify-between items-end">
            <h2 class="text-xl text-gray-600">播单详细</h2>
            <NuxtLink :to="'/playlist/' + video.store_id">
              <div class="flex items-center">
                <svg
                  class="w-5 h-5 text-red-500"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    stroke-linecap="round"
                    stroke-linejoin="round"
                    stroke-width="2"
                    d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"
                  ></path>
                </svg>
                <div class="text-gray-600 text-sm ml-1">进入播单 >></div>
              </div>
            </NuxtLink>
          </div>
          <div
            v-for="video in videolist"
            class="p-2 mt-2 bg-white text-gray-500 rounded-2xl flex items-center"
          >
            <svg
              class="w-6 h-6 text-red-500 ml-1"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M14 10h4.764a2 2 0 011.789 2.894l-3.5 7A2 2 0 0115.263 21h-4.017c-.163 0-.326-.02-.485-.06L7 20m7-10V5a2 2 0 00-2-2h-.095c-.5 0-.905.405-.905.905 0 .714-.211 1.412-.608 2.006L7 11v9m7-10h-2M7 20H5a2 2 0 01-2-2v-6a2 2 0 012-2h2.5"
              ></path>
            </svg>
            <a @click="gotoVideoPage(video)" class="cursor-pointer">
              <span class="ml-1">{{ video.title }}</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";
import { mapMutations } from "vuex";

export default {
  name: "video_detail",
  data: function () {
    return {};
  },
  props: {},
  computed: {
    ...mapState({
      videoObj: (state) => state.videoObj,
    }),
    video: function () {
      if (this.$route.params.id && this.videoObj) {
        if (this.$route.params.id == this.videoObj.videoId) {
          return this.videoObj;
        } else {
          this.$nuxt.error({ statusCode: 404, message: "Data not found" });
          return undefined;
        }
      } else {
        this.$nuxt.error({ statusCode: 404, message: "Data not found" });
        return undefined;
      }
    },
    videolist: function () {
      if (this.$route.params.id && this.videoObj) {
        if (this.$route.params.id == this.videoObj.videoId) {
          return this.$store.state[this.videoObj.store_id].list;
        }
      }
    },
  },
  methods: {
    // 映射store.mutations
    ...mapMutations({
      setVideoObj: "setVideoObj",
    }),
    gotoVideoPage: function (video) {
      this.setVideoObj(video);
      window.$nuxt.$router.push("/video/" + video.videoId);
    },
  },
};
</script>