<template>
  <div>
    <main class="container mx-auto text-center">
      <h1 class="text-4xl text-gray-700 antialiased">{{ siteName }}</h1>
      <div class="flex justify-center py-4">
        <img
          src="/komavideo.png"
          :alt="siteName"
          class="w-24 shadow-xl border-2 border-white rounded"
        />
      </div>
      <div class="flex flex-col items-center">
        <hr class="border border-gray-300 my-5 w-full md:w-9/12 lg:w-6/12" />
        <div
          class="sm:w-full md:w-9/12 lg:w-6/12 leading-10 text-left text-gray-700 text-xl"
        >
          Seth Material 赛斯学习语记与灵修成长的心路历程
          本频道为永久公益非盈利频道。 欢迎转载，但不可断章取义。
          无意侵权，如有版权疑问，请随时联络我调整修正。<br />
          This is a
          Not-for-profit channel. No copyright infringement is intended.
        </div>
        <h2 class="text-2xl text-green-700 pt-10">本站使用技术栈</h2>
        <hr
          class="border border-dashed border-gray-300 my-5 w-full md:w-8/12 lg:w-5/12"
        />
        <ul class="text-gray-600 text-lg">
          <li>Nuxt.js</li>
          <li>Tailwind CSS</li>
          <li>Node.js</li>
        </ul>
      </div>
    </main>
  </div>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "about",
  data: function () {
    return {};
  },
  props: {},
  computed: {
    // 映射store.state
    ...mapState({
      siteName: (state) => state.siteName,
    }),
  },
  methods: {},
};
</script>Ï