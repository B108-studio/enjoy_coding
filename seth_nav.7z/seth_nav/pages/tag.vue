<template>
  <div>
    <div class="flex justify-start items-center">
      <img src="/images/tag.png" alt="播单一览" class="w-10 h-10" />
      <h1 class="text-3xl ml-2 text-gray-600">播单一览</h1>
    </div>
    <hr class="my-4 border border-double border-gray-300" />

    <div
      class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 sm:gap-3 gap-7"
    >
      <TagLabel
        v-for="playlist in playlists"
        :key="playlists.store_id"
        :playlist="playlist"
      />
    </div>
  </div>
</template>

<script>
import { mapState } from "vuex";

export default {
  name: "tag",
  data: function () {
    return {};
  },
  computed: {
    ...mapState({
      playlists: (state) => state.playlists,
    }),
  },
};
</script>