const makeYoutubeVideoUrl = (videoId) => {
    return "https://www.youtube.com/watch?v=" + videoId;
}
const makeYoutubePlaylistUrl = (playlistId) => {
    return "https://www.youtube.com/playlist?list=" + playlistId;
}

export default ({ }, inject) => {
    inject('makeYoutubeVideoUrl', makeYoutubeVideoUrl);
    inject('makeYoutubePlaylistUrl', makeYoutubePlaylistUrl);
}
