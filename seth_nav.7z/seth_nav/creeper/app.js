const fs = require('fs')
const path = require('path')
const { chromium } = require('playwright');
const cheerio = require('cheerio')
const _url = 'https://www.youtube.com/playlist?list='
const playlistId = 'PL1nqXwMyheM44kEcpkpiMi3xxXZi3Dp87'
const target_url = _url + playlistId
const store_id = 'unknown_reality_xiyu'

async function run() {
    const browser = await chromium.launch();
    // const browser = await chromium.launch({ headless: false, slowMo: 100 }); //显示浏览过程
    // 页面访问
    const page = await browser.newPage();
    await page.goto(target_url);
    // await page.waitForTimeout(9993000);
    await page.waitForTimeout(2000);
    await page.evaluate(() => window.scrollTo(0, 2000));
    await page.waitForTimeout(1000);
    await page.evaluate(() => window.scrollTo(0, 2000));
    await page.waitForTimeout(1000);
    await page.evaluate(() => window.scrollTo(0, 2000));
    await page.waitForTimeout(1000);

    // 获取页面HTML
    var content = await page.content()
    const $ = cheerio.load(content)
    let list = []

    $('ytd-playlist-video-renderer').each(async (i, elem) => {

        function saveFile() {
            let url = $(elem).find('ytd-thumbnail img#img').attr('src')
            // console.log(url)
            let ariaLabel = $(elem).find('#video-title').attr('aria-label')
            // console.log(ariaLabel)
            let publishedAt = ariaLabel.slice(ariaLabel.indexOf('HELEN') + 6, ariaLabel.indexOf('前') + 1)
            let title = $(elem).find('#video-title').text().trim()
            let href = $(elem).find('#video-title').attr('href')
            let videoId = href.slice(href.indexOf('=') + 1, href.indexOf('&'))
            // let position = $(elem).find('yt-formatted-string').text()
            let position = href.slice(-1)
            let thumbnail = {
                url: url,
                width: 320,
                height: 180
            }
            if (url) {
                list.push({
                    store_id: store_id,
                    playlistId: playlistId,
                    title: title,
                    publishedAt: publishedAt,
                    thumbnail: thumbnail,
                    videoId: videoId,
                    position: position
                })
            }
        }

        await saveFile()
    })
    await browser.close();
    // console.log(list)

    let fileText = 'export const state = () => ({ \n list: ' + JSON.stringify(list) + '\n})'
    let file = path.resolve(__dirname, '../store/' + store_id + '.js')
    await fs.writeFile(file, fileText, (err) => {
        if (err) throw err;
        console.log('The file has been saved!');
    });

    console.log("Done.")
}

run()
