<template>
  <div class="text-center">
    <h1 class="text-9xl text-gray-600">我去，出错啦！</h1>
  </div>
</template>

<script>
export default {
  name: "error_page",
  data: function () {
    return {};
  },
  props: {},
  computed: {
    displayYMD() {
      return new Date().getFullYear().toString();
    },
  },
};
</script>

<style scoped>
</style>