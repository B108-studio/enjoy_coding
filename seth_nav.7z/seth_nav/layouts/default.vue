<template>
  <div class="bg-gray-200">
    <Header />
    <div class="px-10 py-6">
      <Nuxt />
    </div>
    <Footer />
  </div>
</template>
<script>
import Header from "~/components/shared/Header.vue";
import Footer from "~/components/shared/Footer.vue";
export default {
  components: {
    Header,
    Footer,
  },
};
</script>
