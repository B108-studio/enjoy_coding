import React from 'react'
import Footer from './components/Footer'
import Section_main from './components/Section_main'

function App() {
  return (
    <>
    <Section_main/>
    <Footer/>
    </>
  )
}

export default App