import React from 'react'

export default function Header(props) {
  const addTodo = (e) => {
    const {
      keyCode,
      target: { value }
    } = e
    if (keyCode === 13) {
      const todo =  value
      e.target.value = ''
      props.onKeyUp(todo)
    }

  }
  return (
    <header className="header">
      <h1>todos</h1>
      <input
        className="new-todo"
        autoFocus
        autoComplete="off"
        placeholder="What needs to be done?"
        onKeyUp={addTodo}
      />
    </header>
  )
}
