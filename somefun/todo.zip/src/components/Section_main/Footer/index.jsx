import React from 'react'

export default function Footer({total,actives, showAll,switchShowActive,removeCompleted}) {  
  const remaining = ()=>{
    if(actives<=1) return <strong>{actives} item left</strong>
    return <strong>{actives} items left</strong>
  }  
    return (
        <footer className={total>0?"footer":"hidden"}>
        <span className="todo-count">
          {remaining()}
        </span>
        <ul className="filters">
          <li>
            <a href="#/all" className="{ selected visibility == 'all' }" onClick={showAll}>All</a>
          </li>
          <li>
            <a href="#/active" className="{ selected visibility == 'active' }"
            onClick={()=>switchShowActive(true)}
              >Active</a
            >
          </li>
          <li>
            <a
              href="#/completed"
              className="{ selected visibility == 'completed' }"
              onClick={()=>switchShowActive(false)}
              >Completed</a
            >
          </li>
        </ul>
        <button
          className={total==actives?"hidden":"clear-completed"}
          onClick={removeCompleted}
        >
          Clear completed
        </button>
      </footer>
    )
}
