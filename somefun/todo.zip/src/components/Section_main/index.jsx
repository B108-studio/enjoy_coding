import React, { useState } from 'react'
import Header from './Header'
import Section from './Section'
import Footer from './Footer'

export default function Section_main() {
    const [todos, setTodos] = useState([])

    const addTodo = value => {
        if(value.trim()=='') {
            return
        }
        let todo = {
            id: todos.length,
            title: value,
            completed: false,
            hidden: false
        }
        setTodos([...todos, todo])
    }
    const switchCheckbox = (id) => {
        const newTodos = todos.map(todo => {
            if (todo.id === id) {
                todo.completed = !todo.completed
            }
            return todo
        })
        setTodos(newTodos)
    }
    const removeTodo = (id) => {
        const newTodos = todos.filter(todo => todo.id !== id)
        setTodos(newTodos)
    }
    const switchShowActive = (flag) => {
        // flag为真时，隐藏所有已完成项目，反之隐藏未完成
        const newTodos = todos.map(todo => {
            if (flag) {
                if (todo.completed) {
                    todo.hidden = true
                } else {
                    todo.hidden = false
                }
            } else {
                if (todo.completed) {
                    todo.hidden = false
                } else {
                    todo.hidden = true
                }
            }
            return todo
        })
        setTodos(newTodos)
    }
    const showAll = () => {
        const newTodos = todos.map(todo => {
            todo.hidden = false
            return todo
        })
        setTodos(newTodos)
    }
    const removeCompleted = () => {
        const newTodos = todos.filter(todo => !todo.completed)
        setTodos(newTodos)
    }

    const actives = ()=> {
       const activing = todos.filter(todo => !todo.completed )
        return activing.length
    }
    return (
        <section className="todoapp">
            <Header onKeyUp={addTodo} />
            <Section todos={todos} onChange={switchCheckbox} onClick={removeTodo} />
            <Footer total={todos.length} actives={actives()} switchShowActive={switchShowActive} removeCompleted={removeCompleted} showAll={showAll} />
        </section>
    )
}
