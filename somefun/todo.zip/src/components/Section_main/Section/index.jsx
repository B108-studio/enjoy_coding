import React from 'react'

export default function Section({ todos, onChange, onClick}) {

    const renderItems = (todos) => {
        return todos.map(todo => {
            const { id, title,completed, hidden } = todo
            return (
                <li
                    className={hidden?"hidden":completed?"todo completed":"todo"}
                    key={id}
                >
                    <div className="view">
                        <input className="toggle" type="checkbox" onChange={()=> onChange(id)} />
                        <label dblclick="editTodo(todo)">{title}</label>
                        <button className="destroy" onClick={()=>onClick(id)}></button>
                    </div>
                    <input
                        className="edit"
                        type="text"
                        blur="doneEdit(todo)"
                        keyup="doneEdit(todo)"
                        keyup="cancelEdit(todo)"
                    />
                </li >
            )
        })

    }
    return (
        <section className="main">
            <input
                id="toggle-all"
                className="toggle-all"
                type="checkbox"
            />
            <label htmlFor="toggle-all"></label>
            <ul className="todo-list">
                {renderItems(todos)}
            </ul >
        </section >
    )
}
